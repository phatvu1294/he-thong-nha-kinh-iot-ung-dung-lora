var searchData=
[
  ['bits_5fper_5fpixel',['BITS_PER_PIXEL',['../class_nano_canvas8.html#a5fe2da01e35e6c1e42370c8dbe7e9919',1,'NanoCanvas8::BITS_PER_PIXEL()'],['../class_nano_canvas1.html#a352dbf79226ba1ab07fd905ef2249aeb',1,'NanoCanvas1::BITS_PER_PIXEL()'],['../class_nano_canvas16.html#a3db654af50c33ff901c8ad0e83cb6c79',1,'NanoCanvas16::BITS_PER_PIXEL()']]],
  ['bottom',['bottom',['../struct_s_s_d1306___r_e_c_t.html#ac6f2761573966ed9540d9ac66cf1b471',1,'SSD1306_RECT']]]
];
