var searchData=
[
  ['g_5flcd_5ftype',['g_lcd_type',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gadfa899a135c3bfee48624a3820864b33',1,'g_lcd_type():&#160;ssd1306_generic.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gadfa899a135c3bfee48624a3820864b33',1,'g_lcd_type():&#160;ssd1306_generic.c']]],
  ['getcpuload',['getCpuLoad',['../class_nano_engine_core.html#a249ba97c3cff086d9837d014546867c0',1,'NanoEngineCore']]],
  ['getframerate',['getFrameRate',['../class_nano_engine_core.html#a6cc892046d837463ed7c3996baa983b5',1,'NanoEngineCore']]],
  ['getlrect',['getLRect',['../struct_s_p_r_i_t_e.html#a6ee73688f564cc3a894ed9516e30c448',1,'SPRITE']]],
  ['getrect',['getRect',['../struct_s_p_r_i_t_e.html#a9e207e844a61cf781260fef142bc6aa0',1,'SPRITE']]],
  ['getupdaterect',['getUpdateRect',['../struct_s_p_r_i_t_e.html#a7e3987f9f24d964797a7b0e28a231366',1,'SPRITE']]],
  ['gfx_5fdrawmonobitmap',['gfx_drawMonoBitmap',['../group___l_c_d___g_r_a_p_h_i_c_s___g_e_n_e_r_i_c___a_p_i.html#gac47f2a6a1e4c3f78fd4b793f49694f53',1,'gfx_drawMonoBitmap(lcdint_t x, lcdint_t y, lcduint_t w, lcduint_t h, const uint8_t *buf):&#160;ssd1306_generic.c'],['../group___l_c_d___g_r_a_p_h_i_c_s___g_e_n_e_r_i_c___a_p_i.html#gac47f2a6a1e4c3f78fd4b793f49694f53',1,'gfx_drawMonoBitmap(lcdint_t x, lcdint_t y, lcduint_t w, lcduint_t h, const uint8_t *buf):&#160;ssd1306_generic.c']]]
];
