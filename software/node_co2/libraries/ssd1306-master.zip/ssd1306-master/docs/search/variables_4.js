var searchData=
[
  ['g_5flcd_5ftype',['g_lcd_type',['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gadfa899a135c3bfee48624a3820864b33',1,'g_lcd_type():&#160;ssd1306_generic.c'],['../group___l_c_d___i_n_t_e_r_f_a_c_e___a_p_i.html#gadfa899a135c3bfee48624a3820864b33',1,'g_lcd_type():&#160;ssd1306_generic.c']]]
];
