var searchData=
[
  ['offset',['offset',['../class_nano_canvas8.html#a08e68cddd7df4fffb3630cf7ab67e3de',1,'NanoCanvas8::offset()'],['../class_nano_canvas1.html#a95b690a74b02ff3aeb21426788804a31',1,'NanoCanvas1::offset()'],['../class_nano_canvas16.html#acf597049e362e203ba1b2605dfd6e5fb',1,'NanoCanvas16::offset()']]],
  ['oldselection',['oldSelection',['../struct_s_app_menu.html#ad79da4d78c16e3fbbd2e380dc5763275',1,'SAppMenu']]]
];
