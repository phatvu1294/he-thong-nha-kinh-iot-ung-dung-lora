var searchData=
[
  ['refresh',['refresh',['../class_nano_engine_tiler.html#a0fe7b834cc4900820adf06a62259f53b',1,'NanoEngineTiler::refresh()'],['../class_nano_engine_tiler.html#a6834b72d9e61bbbb9eff3555012cb78c',1,'NanoEngineTiler::refresh(const NanoRect &amp;rect)'],['../class_nano_engine_tiler.html#a35b3de5341c599c87d4650448d60ff13',1,'NanoEngineTiler::refresh(const NanoPoint &amp;point)'],['../class_nano_engine_tiler.html#a7060e92a472d39adb0dc8b8eabb0bc20',1,'NanoEngineTiler::refresh(lcdint_t x1, lcdint_t y1, lcdint_t x2, lcdint_t y2)']]],
  ['refreshscreen',['refreshScreen',['../class_sprite_pool.html#a2dc3ee649258b377b5a6bb7c0e2fdb16',1,'SpritePool']]],
  ['remove',['remove',['../class_sprite_pool.html#adce65ce2eaf9c7389e357f6f039ae7d6',1,'SpritePool']]]
];
