var searchData=
[
  ['data',['data',['../struct_s_fixed_font_info.html#a0f7b369b22f547c125f83c708d8a6c39',1,'SFixedFontInfo::data()'],['../struct_s_p_r_i_t_e.html#ac56b0c16d0bcd810ae1289350df821c3',1,'SPRITE::data()']]]
];
