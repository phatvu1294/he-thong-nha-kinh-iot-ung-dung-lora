var searchData=
[
  ['ascii_5foffset',['ascii_offset',['../struct_s_fixed_font_info.html#ab1ce9f48a6468de8d4677a32be0d516d',1,'SFixedFontInfo']]]
];
