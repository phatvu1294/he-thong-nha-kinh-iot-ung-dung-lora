var searchData=
[
  ['white',['WHITE',['../canvas_8h.html#a99fb83031ce9923c84392b4e92f956b5a283fc479650da98250635b9c3c0e7e50',1,'canvas.h']]]
];
