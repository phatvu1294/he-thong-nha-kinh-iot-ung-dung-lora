var searchData=
[
  ['right',['right',['../struct_s_s_d1306___r_e_c_t.html#a9ed468c58af55753dc61bb3dbdb6275b',1,'SSD1306_RECT']]]
];
