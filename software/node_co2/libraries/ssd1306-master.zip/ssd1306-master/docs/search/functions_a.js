var searchData=
[
  ['move',['move',['../struct___nano_rect.html#adfed33ba72806ccae25fb0260b822a94',1,'_NanoRect']]]
];
