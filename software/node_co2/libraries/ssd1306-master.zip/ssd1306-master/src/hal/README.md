This directory contain platform specific implementation of hardware abstraction layer.

  * arduino dir: for all Arduino platforms (if you use Arduino IDE)
  * avr dir: for plain avr-gcc environment
  * esp dir: for plain esp8266/esp32 environment
